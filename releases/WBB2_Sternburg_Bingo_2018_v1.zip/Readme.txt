Sternburg Bingo 2018 v1 by kill0rz (C) 2018 - visit kill0rz.com

Copyright
#########

Dieser Hack wurde unter "kill0rz' Unilicence v1.0 vom 08.08.2014" veröfentlicht. Diese liegt bei.

Falls dieser Hack von jemanden an eine neuere Version des Bingos angepasst werden möchte, so bedarf dies der Zustimmung von mir.

Beschreibung
############

Dieser Hack ist eine Implementierung des Sternburg Bingos 2018 in das WBB2.3.6pl2

Changelog
#########

v1.0 (02.04.2018)
----
init

Installtion
###########

Lade die alle Dateien in der Struktur von /wbb2/ in deinen Forenordner.
Importiere das Template --> cachen --> nur neue Templates cachen

Importiere danach die beigefügte SQL-Datei.

Konfiguration anpassen: sternburg_bingo_2018.php
======================= ------------------------

Oben in der Datei findest du einen Eintrag, der angepasst werden muss (nicht per ACP einstellbar).

=> $erlaubtegruppen = array("1","2","3");
In das Array trägst du nach dem vorgegebenen Muster alls Gruppen-IDs ein, denen das Benutzen des Scriptes erlaubt sein soll.
Du findest die Gruppen-IDs im ACP --> Gruppen bearbeiten (dann ganz links)


FERTIG!
Nun können du und alle User in den erlaubten Gruppen das Script benutzen!

Viel Spaß bei der Verwendung,
kill0rz
http://kill0rz.com/
Stand: 02.04.2018
